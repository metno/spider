`date.element` <-
function(ts,format="%Y-%m-%d %H:%M:%S",nam) {
# ===========================================================================
# retrieve an element of a date representation ts as numeric
# ts can be either of class character (then format defines the format)
# or of class POSIXt, POSIXct, POSIXlt
# this is a generic function for year(), month(), day(), dofy(), dofm(), etc.
   if (!(class(ts)[1] %in% c("character","POSIXt","POSIXct","POSIXlt"))) {
      stop("** ERROR ** input is not of class character or POSIX")
   }

   doit4one <- function(ts) {
       if ("character" %in% class(ts)) {
           Xlt <- as.POSIXlt(str2Rdate(ts,format=format))
       } else {
           Xlt <- as.POSIXlt(ts)
       }
       unlist(Xlt)[nam]
   }

   qq <- sapply(ts,FUN=doit4one)
   names(qq) <- c()
   qq
}
