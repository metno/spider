`nc4.getFcstRefTime` <-
function(file.name,varid="forecast_reference_time") {
    require(ncdf4)
 
    # open netCDF file
    defs<-nc_open(file.name)
    tcors <- ncvar_get(defs, varid=varid)
    tunits <- ncatt_get(defs, varid,"units")$value
    tt <- nc4t2str(nct=tcors,nct.unit=tunits,format="%Y%m%d%H%M")
    # close file
    nc_close(defs)
    # return the result
    tt    
}


