`nc4.getTime` <-
function(file.name,
         varid="time",
         format="%Y%m%d%H%M") {
    require(ncdf4)
    # open netCDF file
    defs   <- nc_open(file.name)
    tcors  <- ncvar_get(defs, varid=varid)
    tunits <- ncatt_get(defs, varid,"units")$value
    tt     <- nc4t2str(nct=tcors,nct.unit=tunits,format=format)
    # close file
    nc_close(defs)
    # return the result
    tt    
}
