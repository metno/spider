`nc4.getVars` <-
function(file.name) {
    require(ncdf4)
    # open netCDF file
    defs   <- nc_open(file.name)
    varnames<-attr(defs$var,"names")
    # close file
    nc_close(defs)
    # return the result
    varnames    
}
