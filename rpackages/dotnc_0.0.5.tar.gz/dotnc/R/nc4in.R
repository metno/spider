# read netCDF format
`nc4in`<-
function(nc.file,
         nc.varname,
         topdown=F,
         out.dim=NULL,
         proj4=NULL,
         nc.proj4=NULL,
         selection=NULL,
         gridded=T,
         verbose=F) {
#-------------------------------------------------------------------------------
# Read data from ncdf file.
# Parameters:
# + nc.file. character. netCDF file name
# + nc.varname. character. variable name in the netCDF file
# + out.dim. list. variable dimension parameters 
#   out.dim$
#    ndim. integer. number of dimensions
#    tpos. integer. position of the dimension identifying "time"
#    epos. integer. position of the dimension identifying "ensemble member"
#    zpos. integer. position of the dimension identifying "vertical level"
#    names. character vector (1...ndim). variable-specific dimension names
#           names[1]=x must be the Easting coordinate
#           names[2]=y must be the Northing coordinate
#           ...
# + selection. list. select gridded field to read
#   selection$
#    t. character. timestamp to read from the netCDF file (YYYYMMDDHH00)
#    z. numeric. hight level to read from the netCDF file
#    e. numeric. ensemble member to read from the netCDF file
# + proj4 string can be obtained either: 
#     proj4. character. proj4 string set by the user (override nc.proj4)
#   OR
#     nc.proj4. list. read proj4 string from file
#     nc.proj4$
#      var. variable which contains proj4 attribute
#      att. attribute of var which contains proj4 string
#
# example:
# file<-"/lustre/storeB/project/metproduction/products/meps/meps_extracted_2_5km_20161230T06Z.nc"
# nc.varname<-"precipitation_amount_acc"
# ndim<-4
# tpos<-4
# epos<-3
# names<-vector(length=4,mode="character")
# names<-c("x","y","ensemble_member","time") # same names as the nc dimensions
#   # morevoer, these must be all the dimensions of the nc.varname in the nc file
#   # (apart from dimensions that have just 1-field, i.e. they are not really 
#   #  useful dimensions)
#===============================================================================
  require(raster)
  require(ncdf4)
  #
  # open/read/close netcdf file
  if (!file.exists(nc.file)) return(NULL)
  nc <- nc_open(nc.file)
  #
  nc.varnames<-attr(nc$var,"names")
  nc.dimnames<-attr(nc$dim,"names")
  #
  if (is.null(out.dim)) {
    if (gridded) {
      ndim<-2
      names<-vector(length=ndim,mode="character")
      names<-c(dim.names[1],dim.names[2])
      out.dim<-list(ndim=ndim,names=names)
      rm(ndim,names)
    # not gridded
    } else {
      ndim<-1
      names<-vector(length=ndim,mode="character")
      names<-c(dim.names[1])
      out.dim<-list(ndim=ndim,names=names)
      rm(ndim,names)
    }
  }
  out.dimids4nc<-match(out.dim$names,nc.dimnames)
  if (any(is.na(out.dimids4nc))) {
    if (verbose) print(paste("Error while reading data from file",nc.file,
                             "variable",nc.varname,
                             "some of the specified dimension names are not in the file"))
    return(NULL)
  }
  if (!(nc.varname %in% nc.varnames)) {
    if (verbose) print(paste("Error while reading data from file",nc.file,
                             "variable",nc.varname,
                             "the variable name is not available in the file"))
    return(NULL)
  }
  #
  # proj4 string is needed either (1) set by the user or (2) read from nc
  if (is.null(proj4)) {
    aux<-ncatt_get(nc,nc.proj4$var,nc.proj4$att)
    if (!aux$hasatt) return(NULL)
    proj4<-aux$value
  }
  idx<-which(nc.varnames==nc.varname)
  var<-nc$var[[idx]]
  var.size  <- var$varsize
  var.ndims <- var$ndims
  var.dimids<- var$dimids + 1
  out.dimids4var<-match(out.dimids4nc,var.dimids)
  if (any(is.na(out.dimids4var))) return(NULL)
  if (gridded) {
    # define raster
    text.xdim<-paste("nc$dim$",out.dim$names[1],"$vals",sep="")
    text.ydim<-paste("nc$dim$",out.dim$names[2],"$vals",sep="")
    dx<-abs(eval(parse(text=paste(text.xdim,"[1]",sep="")))-
            eval(parse(text=paste(text.xdim,"[2]",sep=""))))
    ex.xmin<-min(eval(parse(text=text.xdim)))-dx/2
    ex.xmax<-max(eval(parse(text=text.xdim)))+dx/2
    dy<-abs(eval(parse(text=paste(text.ydim,"[1]",sep="")))-
            eval(parse(text=paste(text.ydim,"[2]",sep=""))))
    ex.ymin<-min(eval(parse(text=text.ydim)))-dy/2
    ex.ymax<-max(eval(parse(text=text.ydim)))+dy/2
    nx<-eval(parse(text=paste("nc$dim$",out.dim$names[1],"$len",sep="")))
    ny<-eval(parse(text=paste("nc$dim$",out.dim$names[2],"$len",sep="")))
    if (nx>1 & ny>1) {
      is.raster<-T
      r <-raster(ncol=nx, nrow=ny,
                 xmn=ex.xmin, xmx=ex.xmax,
                 ymn=ex.ymin, ymx=ex.ymax,
                 crs=proj4)
      r[]<-NA
    } else {
      is.raster<-F
      s<-NULL
    }
  # not gridded
  } else {
    text.xdim<-paste("nc$dim$",out.dim$names[1],"$vals",sep="")
    nx<-eval(parse(text=paste("nc$dim$",out.dim$names[1],"$len",sep="")))
    ny<-1
    is.raster<-F
    s<-NULL
  }
  #
  # time coordinate
  tsel<-NULL
  ntsel<-0
  if (!is.null(out.dim$tpos)) {
    tcors  <- ncvar_get(nc, varid=out.dim$names[out.dim$tpos])
    tunits <- ncatt_get(nc, out.dim$names[out.dim$tpos],"units")$value
    tall <- nc4t2str(nct=tcors,nct.unit=tunits,format="%Y%m%d%H%M")
    ntall<-length(tall)
    tsel<-1:ntall
    if (!is.null(selection)) {
      if (!is.null(selection$t)) {
        if (any(selection$t %in% tall)) {
          tsel<-which(tall %in% selection$t)
        }
      }
    }
    ntsel<-length(tsel)
  }
  #
  # ensemble member
  esel<-NULL
  nesel<-0
  if (!is.null(out.dim$epos)) {
    eall<-try(ncvar_get(nc, varid=out.dim$names[out.dim$epos]),silent=T)
    if (class(eall)=="try-error")
      eall<-eval(parse(text=paste0("nc$dim$",out.dim$names[out.dim$epos],"$vals")))
    neall<-length(eall)
    esel<-1:neall
    if (!is.null(selection)) {
      if (!is.null(selection$e)) {
        if (any(selection$e %in% eall)) {
          esel<-which(eall %in% selection$e)
          nesel<-length(esel)
        }
      }
    }
  }
  #
  # elevation
  zsel<-NULL
  nzsel<-0
  if (!is.null(out.dim$zpos)) {
    zcors<-ncvar_get(nc, varid=out.dim$names[out.dim$zpos])
    zall<-zcors
    nzall<-length(zcors)
    zsel<-1:nzall
    if (!is.null(selection)) {
      if (!is.null(selection$z)) {
        if (any(selection$z %in% zall)) {
          zsel<-which(zall %in% selection$z)
          nzsel<-length(zsel)
        }
      }
    }
  }
  #
  # labels
  j<-0
  if (ntsel==0 & nzsel==0 & nesel==0) {
    jtot<-1
    labels<-list(t=NULL,e=NULL,z=NULL)
  } else if (ntsel==0) {
    jtot<-nzsel+nesel
    if (nesel>0) {
      elab<-vector(mode="character",length=jtot)
    } else {
      elab<-NULL
    }
    zlab<-vector(mode="character",length=jtot)
    if (nesel>0) {
      zlab<-vector(mode="character",length=jtot)
    } else {
      zlab<-NULL
    }
    labels<-list(t=NULL,e=elab,z=zlab)
  } else {
    jtot<-ntsel
    if (nzsel>0) jtot<-jtot*nzsel
    if (nesel>0) jtot<-jtot*nesel
    tlab<-vector(mode="character",length=jtot)
    if (nesel>0) {
      elab<-vector(mode="character",length=jtot)
    } else {
      elab<-NULL
    }
    zlab<-vector(mode="character",length=jtot)
    if (nesel>0) {
      zlab<-vector(mode="character",length=jtot)
    } else {
      zlab<-NULL
    }
    labels<-list(t=tlab,e=elab,z=zlab)
  }
  #
  # read data
  data.vec<-array(data=NA,dim=c(nx*ny,jtot))
  # no time dimension
  if (ntsel==0) {
    # == cycle for data with 3D (x,z,e) or 4D (x,y,z,e)
    if ((nzsel>0) & (nesel>0)) {
      for (e in esel) {
        for (z in zsel) {
          j<-j+1
          start <- rep(1,var.ndims) # begin with start=(1,1,1,...,1)
          start[out.dimids4var[out.dim$epos]] <- e # change to start=(1,1,1,...,t) 
                                                   # to read ens e
          start[out.dimids4var[out.dim$zpos]] <- z # change to start=(1,1,1,...,t) 
                                                   # to read ens e, lev z
          count <- var.size # begin w/count=(nx,ny,nz,...,nt), reads entire var
          count[out.dimids4var[out.dim$epos]] <- 1 # change to count=(nx,ny,nz,...,1)
                                                   # to read 1ens
          count[out.dimids4var[out.dim$zpos]] <- 1 # change to count=(nx,ny,nz,...,1)
                                                   # to read 1ens, 1z
          data <- ncvar_get( nc, var, start=start, count=count )
          # case of 3D (x,z,e)
          if (length(dim(data))==1) {
            if (topdown) data[1:length(data)]<-data[length(data):1]
            data.vec[,j]<-data
          # case of 4D (x,y,z,e)
          } else if (length(dim(data))==2) {
            if (topdown) for (i in 1:nx) data[i,1:ny]<-data[i,ny:1]
            if (is.raster) {
              r[]<-t(data)
              data.vec[,j]<-getValues(r)
              if (j==1) {s<-r} else {s<-stack(s,r)}
            } else {
              if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                       "for ensemble_member",labels$e[j],
                                       "at elevation",labels$z[j],
                                       ". Try by setting gridded=T"))
              return(NULL)
            }
          # hic sunt leones
          } else {
            if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                     "for ensemble_member",labels$e[j],
                                     "at elevation",labels$z[j]))
            return(NULL)
          }
          labels$e[j]<-eall[e]
          labels$z[j]<-zall[z]
          if (verbose) print(paste("Data for variable",nc.varname,
                                   "for ensemble_member",labels$e[j],
                                   "at elevation",labels$z[j]))
        } # end for z
      } # end for e
    # == cycle for 2D (x,z) or 3D (x,y,z) data
    } else if (nzsel>0) {
      for (z in zsel) {
        j<-j+1
        start <- rep(1,var.ndims) # begin with start=(1,1,1,...,1)
        start[out.dimids4var[out.dim$zpos]] <- z # change to start=(1,1,1,...,t) 
                                                 # to read lev z
        count <- var.size # begin w/count=(nx,ny,nz,...,nt), reads entire var
        count[out.dimids4var[out.dim$zpos]] <- 1 # change to count=(nx,ny,nz,...,1)
                                                 # to read 1z
        data <- ncvar_get( nc, var, start=start, count=count )
        # case of 2D (x,z)
        if (length(dim(data))==1) {
          if (topdown) data[1:length(data)]<-data[length(data):1]
          data.vec[,j]<-data
        # case of 3D (x,y,z)
        } else if (length(dim(data))==2) {
          if (topdown) for (i in 1:nx) data[i,1:ny]<-data[i,ny:1]
          if (is.raster) {
            r[]<-t(data)
            data.vec[,j]<-getValues(r)
            if (j==1) {s<-r} else {s<-stack(s,r)}
          } else {
            if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                     "at elevation",labels$z[j],
                                     ". Try by setting gridded=T"))
            return(NULL)
          }
        # hic sunt leones
        } else {
          if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                   "at elevation",labels$z[j]))
          return(NULL)
        }
        labels$z[j]<-zall[z]
        if (verbose) print(paste("Data for variable",nc.varname,
                                 "at elevation",labels$z[j]))
      } # end for z
    # == cycle for 2D (x,e) or 3D (x,y,e) data
    } else if (nesel>0) {
      for (e in esel) {
        j<-j+1
        start <- rep(1,var.ndims) # begin with start=(1,1,1,...,1)
        start[out.dimids4var[out.dim$epos]] <- e # change to start=(1,1,1,...,t) 
                                                 # to read ens e
        count <- var.size # begin w/count=(nx,ny,nz,...,nt), reads entire var
        count[out.dimids4var[out.dim$epos]] <- 1 # change to count=(nx,ny,nz,...,1)
                                                 # to read 1ens
        data <- ncvar_get( nc, var, start=start, count=count )
        # case of 2D (x,e)
        if (length(dim(data))==1) {
          if (topdown) data[1:length(data)]<-data[length(data):1]
          data.vec[,j]<-data
        # case of 3D (x,y,e)
        } else if (length(dim(data))==2) {
          if (topdown) for (i in 1:nx) data[i,1:ny]<-data[i,ny:1]
          if (is.raster) {
            r[]<-t(data)
            data.vec[,j]<-getValues(r)
            if (j==1) {s<-r} else {s<-stack(s,r)}
          } else {
            if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                     "for ensemble_member",labels$e[j],
                                     ". Try by setting gridded=T"))
            return(NULL)
          }
        # hic sunt leones
        } else {
          if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                   "for ensemble_member",labels$e[j]))
          return(NULL)
        }
        labels$e[j]<-eall[e]
        if (verbose) print(paste("Data for variable",nc.varname,
                                 "for ensemble_member",labels$e[j]))
      } # end for e
    # == cycle for 1D (x) or 2D (x,y) data
    } else {
      j<-j+1
      start <- rep(1,var.ndims) # begin with start=(1,1,1,...,1)
      count <- var.size # begin w/count=(nx,ny,nz,...,nt), reads entire var
      data <- ncvar_get( nc, var, start=start, count=count )
      # case of 1D (x)
      if (length(dim(data))==1) {
        if (topdown) data[1:length(data)]<-data[length(data):1]
        data.vec[,j]<-data
      # case of 2D (x,y)
      } else if (length(dim(data))==2) {
        if (topdown) for (i in 1:nx) data[i,1:ny]<-data[i,ny:1]
        if (is.raster) {
          r[]<-t(data)
          data.vec[,j]<-getValues(r)
          if (j==1) {s<-r} else {s<-stack(s,r)}
        } else {
          if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                   ". Try by setting gridded=T"))
          return(NULL)
        }
      # hic sunt leones
      } else {
        if (verbose) print(paste("Error while reading data for variable",nc.varname))
        return(NULL)
      }
      if (verbose) print(paste("Data for variable",nc.varname))
    }
  #
  # time dimension available
  } else {
    for (t in tsel) {
      # == cycle for 4D (x,z,e,t) or 5D (x,y,z,e,t) data
      if ((nzsel>0) & (nesel>0)) {
        for (e in esel) {
          for (z in zsel) {
            j<-j+1
            start <- rep(1,var.ndims) # begin with start=(1,1,1,...,1)
            start[out.dimids4var[out.dim$tpos]] <- t # change to start=(1,1,1,...,t) 
                                                     # to read timestep t
            start[out.dimids4var[out.dim$epos]] <- e # change to start=(1,1,1,...,t) 
                                                     # to read timestep t, ens e
            start[out.dimids4var[out.dim$zpos]] <- z # change to start=(1,1,1,...,t) 
                                                     # to read timestep t, ens e, lev z
            count <- var.size # begin w/count=(nx,ny,nz,...,nt), reads entire var
            count[out.dimids4var[out.dim$tpos]] <- 1 # change to count=(nx,ny,nz,...,1)
                                                     # to read 1 tstep
            count[out.dimids4var[out.dim$epos]] <- 1 # change to count=(nx,ny,nz,...,1)
                                                     # to read 1 tstep, 1ens
            count[out.dimids4var[out.dim$zpos]] <- 1 # change to count=(nx,ny,nz,...,1)
                                                     # to read 1 tstep, 1ens, 1z
            data <- ncvar_get( nc, var, start=start, count=count )
            # case of 4D (x,z,e,t)
            if (length(dim(data))==1) {
              if (topdown) data[1:length(data)]<-data[length(data):1]
              data.vec[,j]<-data
            # case of 5D (x,y,z,e,t)
            } else if (length(dim(data))==2) {
              if (topdown) for (i in 1:nx) data[i,1:ny]<-data[i,ny:1]
              if (is.raster) {
                r[]<-t(data)
                data.vec[,j]<-getValues(r)
                if (j==1) {s<-r} else {s<-stack(s,r)}
              } else {
                if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                         "at timestep",labels$t[j],
                                         "for ensemble_member",labels$e[j],
                                         "at elevation",labels$z[j],
                                         ". Try by setting gridded=T"))
                return(NULL)
              }
            # hic sunt leones
            } else {
              if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                       "at timestep",labels$t[j],
                                       "for ensemble_member",labels$e[j],
                                       "at elevation",labels$z[j]))
              return(NULL)
            }
            labels$t[j]<-tall[t]
            labels$e[j]<-eall[e]
            labels$z[j]<-zall[z]
            if (verbose) print(paste("Data for variable",nc.varname,
                                     "at timestep",labels$t[j],
                                     "for ensemble_member",labels$e[j],
                                     "at elevation",labels$z[j]))
          } # end for z
        } # end for e
      # == cycle for 3D (x,z,t) or 4D (x,y,z,t) data
      } else if (nzsel>0) {
        for (z in zsel) {
          j<-j+1
          start <- rep(1,var.ndims) # begin with start=(1,1,1,...,1)
          start[out.dimids4var[out.dim$tpos]] <- t # change to start=(1,1,1,...,t) 
                                                   # to read timestep t
          start[out.dimids4var[out.dim$zpos]] <- z # change to start=(1,1,1,...,t) 
                                                   # to read timestep t, ens e, lev z
          count <- var.size # begin w/count=(nx,ny,nz,...,nt), reads entire var
          count[out.dimids4var[out.dim$tpos]] <- 1 # change to count=(nx,ny,nz,...,1)
                                                   # to read 1 tstep
          count[out.dimids4var[out.dim$zpos]] <- 1 # change to count=(nx,ny,nz,...,1) 
                                                   # to read 1 tstep, 1ens, 1z
          data <- ncvar_get( nc, var, start=start, count=count )
          # case of 3D (x,z,t)
          if (length(dim(data))==1) {
            if (topdown) data[1:length(data)]<-data[length(data):1]
            data.vec[,j]<-data
          # case of 4D (x,y,z,t)
          } else if (length(dim(data))==2) {
            if (topdown) for (i in 1:nx) data[i,1:ny]<-data[i,ny:1]
            if (is.raster) {
              r[]<-t(data)
              data.vec[,j]<-getValues(r)
              if (j==1) {s<-r} else {s<-stack(s,r)}
            } else {
              if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                       "at timestep",labels$t[j],
                                       "at elevation",labels$z[j],
                                       ". Try by setting gridded=T"))
              return(NULL)
            }
          # hic sunt leones
          } else {
            if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                     "at timestep",labels$t[j],
                                     "at elevation",labels$z[j]))
            return(NULL)
          }
          labels$t[j]<-tall[t]
          labels$z[j]<-zall[z]
          if (verbose) print(paste("Data for variable",nc.varname,
                                   "at timestep",labels$t[j],
                                   "at elevation",labels$z[j]))
        } # end for z
      # == cycle for 3D (x,e,t) or 4D (x,y,e,t) data
      } else if (nesel>0) {
        for (e in esel) {
          j<-j+1
          start <- rep(1,var.ndims) # begin with start=(1,1,1,...,1)
          start[out.dimids4var[out.dim$tpos]] <- t # change to start=(1,1,1,...,t) 
                                                   # to read timestep t
          start[out.dimids4var[out.dim$epos]] <- e # change to start=(1,1,1,...,t) 
                                                 # to read timestep t, ens e, lev z
          count <- var.size # begin w/count=(nx,ny,nz,...,nt), reads entire var
          count[out.dimids4var[out.dim$tpos]] <- 1 # change to count=(nx,ny,nz,...,1)
                                                   # to read 1 tstep
          count[out.dimids4var[out.dim$epos]] <- 1 # change to count=(nx,ny,nz,...,1) 
                                                   # to read 1 tstep, 1ens, 1z
          data <- ncvar_get( nc, var, start=start, count=count )
          # case of 3D (x,e,t)
          if (length(dim(data))==1) {
            if (topdown) data[1:length(data)]<-data[length(data):1]
            data.vec[,j]<-data
          # case of 4D (x,y,e,t)
          } else if (length(dim(data))==2) {
            if (topdown) for (i in 1:nx) data[i,1:ny]<-data[i,ny:1]
            if (is.raster) {
              r[]<-t(data)
              data.vec[,j]<-getValues(r)
              if (j==1) {s<-r} else {s<-stack(s,r)}
            } else {
              if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                       "at timestep",labels$t[j],
                                       "for ensemble_member",labels$e[j],
                                       ". Try by setting gridded=T"))
              return(NULL)
            }
          # hic sunt leones
          } else {
            if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                     "at timestep",labels$t[j],
                                     "for ensemble_member",labels$e[j]))
            return(NULL)
          }
          labels$t[j]<-tall[t]
          labels$e[j]<-eall[e]
          if (verbose) print(paste("Data for variable",nc.varname,
                                   "at timestep",labels$t[j],
                                   "for ensemble_member",labels$e[j]))
        } # end for e
      # == cycle for 2D (x,t) or 3D (x,y,t) data
      } else {
        j<-j+1
        start <- rep(1,var.ndims) # begin with start=(1,1,1,...,1)
        start[out.dimids4var[out.dim$tpos]] <- t # change to start=(1,1,1,...,t) 
                                                 # to read timestep t
        count <- var.size # begin w/count=(nx,ny,nz,...,nt), reads entire var
        count[out.dimids4var[out.dim$tpos]] <- 1 # change to count=(nx,ny,nz,...,1) 
                                                 # to read 1 tstep
        data <- ncvar_get( nc, var, start=start, count=count )
        # case of 3D (x,t)
        if (length(dim(data))==1) {
          if (topdown) data[1:length(data)]<-data[length(data):1]
          data.vec[,j]<-data
        # case of 4D (x,y,t)
        } else if (length(dim(data))==2) {
          if (topdown) for (i in 1:nx) data[i,1:ny]<-data[i,ny:1]
          if (is.raster) {
            r[]<-t(data)
            data.vec[,j]<-getValues(r)
            if (j==1) {s<-r} else {s<-stack(s,r)}
          } else {
            if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                     "at timestep",labels$t[j],
                                     ". Try by setting gridded=T"))
            return(NULL)
          }
        # hic sunt leones
        } else {
          if (verbose) print(paste("Error while reading data for variable",nc.varname,
                                   "at timestep",labels$t[j]))
          return(NULL)
        }
        labels$t[j]<-tall[t]
        if (verbose) print(paste("Data for variable",nc.varname,
                                 "at timestep",labels$t[j]))
      } 
    } # end for "time"
  } # end if on "time/no-time"
  nc_close(nc)
  return(list(data=data.vec,stack=s,labels=labels))
}
