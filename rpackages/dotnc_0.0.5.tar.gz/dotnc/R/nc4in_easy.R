# read seNorge2 file, netCDF format
`nc4in_easy`<-
function(file,var.name,proj.name="UTM_Zone_33",proj.att="projection",topdown=F,
         xdim.name=NULL,ydim.name=NULL,t=NULL,ens.m=NULL,projstr=NULL) {
  require(raster)
  require(ncdf4)
  # open/read/close netcdf file
  if (!file.exists(file)) return(NULL)
  nc <- nc_open(file)
  var.names<-attr(nc$var,"names")
  if (is.null(xdim.name) & is.null(ydim.name)) {
    dim.names<-attr(nc$dim,"names")
    xdim.name<-dim.names[1]
    ydim.name<-dim.names[2]
  }
  if (!(var.name%in%var.names)) return(NULL)
  idx<-which(var.names==var.name)
  var<-nc$var[[idx]]
  varsize <- var$varsize
  ndims   <- var$ndims
  #
  if (ndims>2) {
    tcors  <- ncvar_get(nc, varid="time")
    tunits <- ncatt_get(nc, "time","units")$value
    tt.all <- nc4t2str(nct=tcors,nct.unit=tunits,format="%Y%m%d%H%M")
    if (any(t %in% tt.all)) {
      t.i<-which(t==tt.all)
    } else {
      t.i<-1
    }
    tt<-tt.all[t.i]
#    varsize <- var.atts$varsize
#    ndims   <- var.atts$ndims
    nt      <- varsize[ndims]  # Remember timelike dim is always the LAST dimension!
    # Initialize start and count to read one timestep of the variable.
    start <- rep(1,ndims) # begin with start=(1,1,1,...,1)
    start[ndims] <- t.i # change to start=(1,1,1,...,i) to read timestep i
    count <- varsize # begin w/count=(nx,ny,nz,...,nt), reads entire var
    count[ndims] <- 1 # change to count=(nx,ny,nz,...,1) to read 1 tstep
    data <- ncvar_get( nc, var, start=start, count=count )
    # Now read in the value of the timelike dimension
    timeval <- tt.all[t.i] 
    print(paste("Data for variable",var$name,"at timestep",t.i,
     " (time value=",timeval,"):"))
  } else {
    data <- ncvar_get( nc, var)
  }
  #
  if (is.null(projstr)) {
    aux<-ncatt_get(nc,proj.name,proj.att)
    projstr<-aux$value
  }

  text.xdim<-paste("nc$dim$",xdim.name,"$vals",sep="")
  text.ydim<-paste("nc$dim$",ydim.name,"$vals",sep="")
  dx<-abs(eval(parse(text=paste(text.xdim,"[1]",sep="")))-
          eval(parse(text=paste(text.xdim,"[2]",sep=""))))
  ex.xmin<-min(eval(parse(text=text.xdim)))-dx/2
  ex.xmax<-max(eval(parse(text=text.xdim)))+dx/2
  dy<-abs(eval(parse(text=paste(text.ydim,"[1]",sep="")))-
          eval(parse(text=paste(text.ydim,"[2]",sep=""))))
  ex.ymin<-min(eval(parse(text=text.ydim)))-dy/2
  ex.ymax<-max(eval(parse(text=text.ydim)))+dy/2
  nx<-eval(parse(text=paste("nc$dim$",xdim.name,"$len",sep="")))
  ny<-eval(parse(text=paste("nc$dim$",ydim.name,"$len",sep="")))
  nc_close(nc)
  if (topdown) {
    for (i in 1:nx) data[i,1:ny]<-data[i,ny:1]
  }
# Define raster variable "r"
  r <-raster(ncol=nx, nrow=ny,
             xmn=ex.xmin, xmx=ex.xmax,
             ymn=ex.ymin, ymx=ex.ymax,
             crs=projstr)
  r[]<-NA
  if (is.null(ens.m)) {
    # put data on raster variable (t=transpose)
    r[]<-t(data)
    data<-getValues(r)
  } else {
    r[]<-t(data[,,ens.m])
    data<-getValues(r)
  }
  return(list(data=data,raster=r))
}
