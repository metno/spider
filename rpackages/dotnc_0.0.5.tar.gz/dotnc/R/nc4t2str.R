`nc4t2str` <- 
function (nct, nct.unit, format = "%Y%m%d%H%M") {
    fmt.nc <- "%Y-%m-%d %H:%M:00"
    rd.expl <- str2Rdate("190001010000", format = "%Y%m%d%H%M")
    ss.expl <- Rdate2str(rd.expl, format = fmt.nc)
    ll <- nchar(ss.expl)
    reference <- nct.unit
    t.unit <- switch(substr(reference, 1, 4), 
                     minu = "T",
                     hour = "H", 
                     days = "D",
                     mont = "M",
                     year = "Y",
                     seco = "S")
    c.start <- switch(t.unit, T = 15, H = 13, D = 12, M = 14, Y = 13, S=15)
    ref.date.str <- substr(reference, c.start, stop = c.start + ll - 1)
    if (nchar(ref.date.str)<nchar(ss.expl)) {
      ll1 <- nchar(ref.date.str)
      aux<- substr(ss.expl, (ll1+1), stop = ll)
      ref.date.str<-paste(ref.date.str,":00",sep="")
    }
#           ref.date <- str2Rdate(ref.date.str, format = fmt.nc)
    ref.date <- str2Rdate(ref.date.str)
    if (!(t.unit %in% c("Y", "M", "T", "H", "D", "S"))) {
        stop("Time conversion not available")
    }
    if (t.unit %in% c("T", "H", "D", "S")) {
        t.scal <- switch(t.unit, T = 60, H = 3600, D = 86400, S=1)
        secs.elapsed <- nct * t.scal
        r.tims <- ref.date + secs.elapsed
    }
    if (t.unit == "Y") {
        yy.ref <- as.numeric(Rdate2str(ref.date, format = "%Y"))
        rr.ref <- Rdate2str(ref.date, format = "%m%d%H%M")
        yy.ch <- sprintf("%03d", nct + yy.ref)
        dd.ch <- sapply(yy.ch, FUN = function(x) paste(x, rr.ref, 
            sep = ""))
        r.tims <- str2Rdate(dd.ch, format = "%Y%m%d%H%M")
    }
    if (t.unit == "M") {
        yy.ref <- as.numeric(Rdate2str(ref.date, format = "%Y"))
        mm.ref <- as.numeric(Rdate2str(ref.date, format = "%m"))
        rr.ref <- Rdate2str(ref.date, format = "%d%H%M")
        mm <- nct + (yy.ref * 12 + mm.ref)
        hhy <- trunc((mm - 1)/12)
        hhm <- mm - hhy * 12
        dd.ch <- sapply(1:length(hhy), 
                 FUN = function(ii) paste(sprintf("%04d", 
                     hhy[ii]), sprintf("%02d", hhm[ii]), rr.ref, sep = ""))
        r.tims <- str2Rdate(dd.ch, format = "%Y%m%d%H%M")
    }
    Rdate2str(r.tims, format = format)
}
