`str2nct` <- 
function(str,t.unit,format="%Y%m%d%H%M",
         t.ref="190001010000",format.ref="%Y%m%d%H%M") {

      # seconds elapsed
      ss <- str2Rdate(str,format=format)
      ss.ref <- str2Rdate(t.ref,format=format.ref)
      secs.elapsed <- unclass(ss)-unclass(ss.ref)
      names(secs.elapsed) <- c()

      # date indicator in netcdf attribute
      fmt.nc <- "%Y-%m-%d %H:%M:00"
      ref.date <- Rdate2str(ss.ref,format=fmt.nc)

      # years, months elapsed
      yy <- year(str,format=format)
      yy.ref <- year(t.ref,format=format.ref)
      mm <- month(str,format=format)
      mm.ref <- month(t.ref,format=format.ref)
      yeas.elapsed <- yy-yy.ref
      names(yeas.elapsed) <- c()
      mons.elapsed <- (12*yy+(mm-1))-(12*yy.ref+(mm.ref-1))
      names(mons.elapsed) <- c()

      tt <- switch(t.unit,
          "T" = secs.elapsed/60,
          "H" = secs.elapsed/3600,
          "D" = secs.elapsed/86400,
          "M" = mons.elapsed,
          "Y" = yeas.elapsed)
      tt.attr <- switch(t.unit,
          "T" = paste("minutes since",ref.date,sep=" "),
          "H" = paste("hours since",ref.date,sep=" "),
          "D" = paste("days since",ref.date,sep=" "),
          "M" = paste("months since",ref.date,sep=" "),
          "Y" = paste("years since",ref.date,sep=" "))
      attr(tt,"since.lab") <- tt.attr
      attr(tt,"tzone") <- NULL

      tt
}

