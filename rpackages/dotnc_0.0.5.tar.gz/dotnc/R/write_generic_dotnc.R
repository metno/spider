#+ Write a netcdf file
`write_generic_dotnc`<-function(nc.file="foo.nc",
                                dims=NULL,
                                vars=NULL,
                                glob_attrs=NULL) {
#------------------------------------------------------------------------------
# Input
# nc.file
# dims=list(list(name="a",units="b",vals=1:10,unlim=TRUE,attr=list()),
#           list(name="a",units="b",data=1:10,unlim=TRUE,attr=list())),
# vars=list(list(varname="a",attr=list(),dim_names=c(),data=1:10),
#           list(varname="a",attr=list(),dim_names=c(),data=1:10)),
# glob_attrs=list(list(name="a",...))
#==============================================================================
#
#------------------------------------------------------------------------------
# make the list of dimensions and attributes
dim_list<-list()
attr_list<-list()
cont_attr<-0
for (i in 1:length(dims)) {
  if (is.null(dims[[i]]$unlim)) dims[[i]]$unlim<-F
  if (is.null(dims[[i]]$is_time)) dims[[i]]$is_time<-F
  if (dims[[i]]$is_time) {
    vals<-str2nc4t(str=dims[[i]]$vals,
                   t.unit=dims[[i]]$times.unit,
                   format=dims[[i]]$times.format,
                   format.ref=dims[[i]]$timeref.format,
                   t.ref=dims[[i]]$timeref)
    dims[[i]]$vals<-as.integer(vals)
    units<-attr(vals,"since.lab")
  } else {
    units<-dims[[i]]$units
  }
  dim_list[[i]]<-ncdim_def(name=dims[[i]]$name,
                           units=units,
                           vals=dims[[i]]$vals,
                           unlim=dims[[i]]$unlim)
  if (!is.null(dims[[i]]$attr)) {
    for (j in 1:length(dims[[i]]$attr)) {
      if ( is.null(dims[[i]]$attr[[j]]$attname) | 
           is.null(dims[[i]]$attr[[j]]$attval)  |
           is.null(dims[[i]]$attr[[j]]$prec) ) {
        print("ERROR in write_generic_dotnc code \"dim01\" ")  
        return(NULL)
      }
      cont_attr<-cont_attr+1
      attr_list[[cont_attr]]<-list(varid=dims[[i]]$name,
                                   attname=dims[[i]]$attr[[j]]$attname,
                                   attval=dims[[i]]$attr[[j]]$attval,
                                   prec=dims[[i]]$attr[[j]]$prec)
    }
  }
}
#
#------------------------------------------------------------------------------
# make the list of variables and corresponding attributes
var_list<-list()
for (i in 1:length(vars)) {
  var_dims<-list()
  for (j in 1:length(vars[[i]]$dim_names)) {
    for (k in 1:length(dims)) {
      if (dims[[k]]$name==vars[[i]]$dim_names[j]) {
        var_dims[[j]]<-dim_list[[k]]
        break
      }
    }
  }
  if (length(var_dims)!=length(vars[[i]]$dim_names)) {
    print("ERROR in write_generic_dotnc code \"var01\" ")  
    return(NULL)
  }
  if (is.null(vars[[i]]$is_time)) vars[[i]]$is_time<-F
  if (vars[[i]]$is_time) {
    vals<-vars[[i]]$vals
    for (j in 1:length(var_dims)) {
      vals[,j]<-str2nc4t(str=vars[[i]]$vals[,j],
                         t.unit=dims[[i]]$times.unit,
                         format=dims[[i]]$times.format,
                         format.ref=dims[[i]]$timeref.format,
                         t.ref=dims[[i]]$timeref)
    }
    units<-attr(vals,"since.lab")
    attr(vals,"since.lab")<-NULL
    attr(vals,"tzone")<-NULL
    vars[[i]]$vals<-t(vals)
  } else {
    units<-vars[[i]]$units
  }
  if (is.null(vars[[i]]$missval)) vars[[i]]$missval<-1.e30
  if (is.null(vars[[i]]$longname)) vars[[i]]$longname<-vars[[i]]$name
  if (is.null(vars[[i]]$prec)) vars[[i]]$prec<-"float"
  if (is.null(vars[[i]]$shuffle)) vars[[i]]$shuffle<-FALSE
  if (is.null(vars[[i]]$compression)) vars[[i]]$compression<-9
  if (is.null(vars[[i]]$chunksizes)) vars[[i]]$chunksizes<-NA
  if (is.null(vars[[i]]$verbose)) vars[[i]]$verbose<-FALSE
  var_list[[i]]<-ncvar_def(name=vars[[i]]$name,
                           units=units,
                           dim=var_dims,
                           missval=vars[[i]]$missval,
                           prec=vars[[i]]$prec,
                           shuffle=vars[[i]]$shuffle,
                           compression=vars[[i]]$compression,
                           chunksizes=vars[[i]]$chunksizes,
                           verbose=vars[[i]]$verbose)
  if (!is.null(vars[[i]]$attr)) {
    for (j in 1:length(vars[[i]]$attr)) {
      if ( is.null(vars[[i]]$attr[[j]]$attname) | 
           is.null(vars[[i]]$attr[[j]]$attval)  |
           is.null(vars[[i]]$attr[[j]]$prec) ) {
        print("ERROR in write_generic_dotnc code \"var02\" ")  
        return(NULL)
      }
      cont_attr<-cont_attr+1
      attr_list[[cont_attr]]<-list(varid=var_list[[i]],
                                   attname=vars[[i]]$attr[[j]]$attname,
                                   attval=vars[[i]]$attr[[j]]$attval,
                                   prec=vars[[i]]$attr[[j]]$prec)
    }
  }
}
#
#------------------------------------------------------------------------------
# add global attributes to the list of attributes
if (!is.null(glob_attrs)) {
  for (i in 1:length(glob_attrs)) {
    if ( is.null(glob_attrs[[i]]$attname) | 
         is.null(glob_attrs[[i]]$attval)  |
         is.null(glob_attrs[[i]]$prec) ) {
      print("ERROR in write_generic_dotnc code \"glob01\" ")  
      return(NULL)
    }
    cont_attr<-cont_attr+1
    attr_list[[cont_attr]]<-list(varid=0,
                                 attname=glob_attrs[[i]]$attname,
                                 attval=glob_attrs[[i]]$attval,
                                 prec=glob_attrs[[i]]$prec)
  }
}
#
#------------------------------------------------------------------------------
# function to add attributes
add_att_to_nc <-
function(list,...) {
  ncatt_put(nc=nc_con,
            varid=list[[1]],
            attname=list[[2]],
            attval=list[[3]],
            prec=list[[4]],...)
  return()
}
#
#------------------------------------------------------------------------------
# Create the file
nc_con <- nc_create(filename=nc.file,
                    vars=var_list,
                    force_v4=T)
#h <- lapply(attr_list,FUN=add_att_to_nc)
h <- lapply(attr_list,
            FUN=function(list,...) {
              ncatt_put(nc=nc_con,
                        varid=list$varid,
                        attname=list$attname,
                        attval=list$attval,
                        prec=list$prec,...)
              return()} )
h <- lapply(var_list,
            FUN=function(list,...) {
              for (i in 1:length(vars)) 
                if (vars[[i]]$name==list$name) break
              ncvar_put(nc=nc_con,
                        varid=list,
                        vals=vars[[i]]$vals)
              return()} )
#
#------------------------------------------------------------------------------
# Close the file
nc_close(nc_con)
#
#------------------------------------------------------------------------------
# Normal exit
return(0)

}

#man pages
##--------------------------------
## Make a few dimensions we can use
##--------------------------------
#nx <- 3
#ny <- 4
#nt <- 5
#xvals <- (1:nx)*100.
#dimX <- ncdim_def( "X", "meters", xvals )
#dimY <- ncdim_def( "Y", "meters", (1:ny)*100. )
#dimT <- ncdim_def( "Time", "seconds", (1:nt)/100., unlim=TRUE )
##-------------------------------------------------------------------
## Make varables of various dimensionality, for illustration purposes
##-------------------------------------------------------------------
#mv <- 1.e30 # missing value to use
#var1d <- ncvar_def( "var1d", "units", dimX, mv )
#var2d <- ncvar_def( "var2d", "units", list(dimX,dimY), mv )
#var3d <- ncvar_def( "var3d", "units", list(dimX,dimY,dimT), mv )
##---------------------
## Create the test file
##---------------------
#nc <- nc_create( "writevals.nc", list(var1d,var2d,var3d) )
##----------------------------
## Write some data to the file
##----------------------------
#data1d <- runif(nx)
#ncvar_put( nc, var1d, data1d ) # no start or count: write all values
#ncvar_put( nc, var1d, 27.5, start=3, count=1 ) # Write a value to the third slot
#data2d <- runif(nx*ny)
#ncvar_put( nc, var2d, data2d ) # no start or count: write all values
#22
#ncvar_put
#xvals <- (1:nx)*100.
#dimX <- ncdim_def( "X", "meters", xvals )
#dimY <- ncdim_def( "Y", "meters", (1:ny)*100. )
#dimT <- ncdim_def( "Time", "seconds", (1:nt)/100., unlim=TRUE )
##-------------------------------------------------------------------
## Make varables of various dimensionality, for illustration purposes
##-------------------------------------------------------------------
#mv <- 1.e30 # missing value to use
#var1d <- ncvar_def( "var1d", "units", dimX, mv )
#var2d <- ncvar_def( "var2d", "units", list(dimX,dimY), mv )
#var3d <- ncvar_def( "var3d", "units", list(dimX,dimY,dimT), mv )
##---------------------
## Create the test file
##---------------------
#nc <- nc_create( "writevals.nc", list(var1d,var2d,var3d) )
##----------------------------
## Write some data to the file
##----------------------------
#data1d <- runif(nx)
#ncvar_put( nc, var1d, data1d ) # no start or count: write all values
#ncvar_put( nc, var1d, 27.5, start=3, count=1 ) # Write a value to the third slot
#data2d <- runif(nx*ny)
#ncvar_put( nc, var2d, data2d ) # no start or count: write all values
##--------------------------------
## Write a 1-d slice to the 2d var
##--------------------------------
#ncvar_put( nc, var2d, data1d, start=c(1,2), count=c(nx,1) )
##--------------------------------------------------------------
## Note how "-1" in the count means "the whole dimension length",
## which equals nx in this case
##--------------------------------------------------------------
#ncvar_put( nc, var2d, data1d, start=c(1,3), count=c(-1,1) )
##-------------------------------------------------------------------------------
## The 3-d variable has an unlimited dimension.  We will loop over the timesteps,
## writing one 2-d slice per timestep.
##-------------------------------------------------------------------------------
#for( i in 1:nt)
#ncvar_put( nc, var3d, data2d, start=c(1,1,i), count=c(-1,-1,1) )
#nc_close(nc)

#----------------------------------------------------------------------
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# files to read
#cristianl@xvis-m3a:/lustre/storeB/users/cristianl/waf_paper/xval_1/20180315$ ncdump -h met_analysis_1_0km_nordic_20180315T18Z.nc 
#netcdf met_analysis_1_0km_nordic_20180315T18Z {
#dimensions:
#	time = UNLIMITED ; // (1 currently)
#	x = 254 ;
#	ensemble_member = 10 ;
#variables:
#	int time(time) ;
#		time:long_name = "time" ;
#		time:standard_name = "time" ;
#		time:units = "seconds since 1970-01-01 00:00:00 +00:00" ;
#	float lat(x) ;
#	float lon(x) ;
#	float altitude(x) ;
#	float air_temperature_2m(time, ensemble_member, x) ;
#		air_temperature_2m:standard_name = "air_temperature" ;
#		air_temperature_2m:units = "K" ;
#		air_temperature_2m:coordinates = "lon lat" ;
#	double forecast_reference_time ;
#		forecast_reference_time:standard_name = "forecast_reference_time" ;
#		forecast_reference_time:units = "seconds since 1970-01-01 00:00:00 +00:00" ;
#
#// global attributes:
#		:history = "2018-08-15 14:18:22: post-processing by gridpp\n",
#			"2018-07-31 15:52:04: post-processing by gridpp" ;
#}

#----------------------------------------------------------------------
#----------------------------------------------------------------------
#----------------------------------------------------------------------
# files to write
#netcdf format {
#dimensions:
#   time = UNLIMITED;
#   leadtime  = 48;
#   location = 10;
#   ensemble = 21;
#   threshold = 11;
#   quantile = 11;
#   ensemble_member = 5;
#variables:
#   int time(time);                                   // Valid time of forecast initialization in
#                                                     // number of seconds since 1970-01-01 00:00:00 +00:00
#   float leadtime(leadtime);                         // Number of hours since forecast init
#   int location(location);                           // Id for each station location
#   float threshold(threshold);
#   float quantile(quantile);                         // Numbers between 0 and 1
#   int ensemble_member(ensemble_member);             // Ensemble member number
#   float lat(location);                              // Decimal degrees latitude
#   float lon(location);                              // Decimal degrees longitude
#   float altitude(location);                         // Altitude in meters
#   float obs(time, leadtime, location);              // Observations
#   float fcst(time, leadtime, location);             // Deterministic forecast
#   float cdf(time, leadtime, location, threshold);   // Accumulated prob at threshold
#   float pdf(time, leadtime, location, threshold);   // Probability density at threshold
#   float x(time, leadtime, location, quantile);      // Threshold corresponding to quantile
#   float pit(time, leadtime, location);              // CDF for threshold=observation
#   float ensemble(time, leadtime, location, ensemble_member); // Ensemble forecasts
#
#// global attributes:
#   : long_name = "Precipitation";                    // Used to label axes in plots
#   : standard_name = "precipitation_amount";         // NetCDF/CF standard name of the forecast variable
#   : x0 = 0;                                         // Discrete mass at lower boundary (e.g. 0 mm for precipitation). Omit otherwise.
#   : x1 = 100;                                       // Discrete mass at upper boundary (e.g. 100% for relative humidity). Omit otherwise.
#   : verif_version = "1.0.0";                        // Not required, but will be parsed in the future if format changes
#   }
