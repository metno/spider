`year` <-
function(ts,format="%Y-%m-%d") {
  date.element(ts,format=format,nam="year")+1900
}
