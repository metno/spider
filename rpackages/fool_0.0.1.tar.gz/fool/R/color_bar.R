# Function to plot color bar
`color.bar` <- function(col, breaks, nticks=11, title='', cutTails=T,
                      legtxt="",legdig=0,
                      x1=1000000,
                      y1=6450000,
                      x2=1050000,
                      y2=7530000,
                      dx=50000,
                      cex=2.5) {
#    scale = (length(lut)-1)/(max-min)
  nbr<-length(breaks)
  if (cutTails) {
    min<-min(breaks[2:(nbr-1)])
    max<-max(breaks[2:(nbr-1)])
    ticks<-round(seq(2, (nbr-1), len=nticks),0)
  } else {
    min<-min(breaks)
    max<-max(breaks)
    ticks<-round(seq(1, nbr, len=nticks),0)
  }
  dy<-(y2-y1)/length(col)
  rect(x1+dx,y1,
       x2+1.5*dx,y2+dx,
       col="white", border=NA)
  text((x2+1.5*dx/2),
       (y1+dy/2+(ticks-1)*dy),
       round(breaks[ticks],legdig),
       cex=cex)
  text((x1+x2)/2,
        y2+dx/2,
        legtxt,
        cex=cex)
  for (i in 1:(length(col))) {
   y = (i-1)*dy + y1 
   rect(x1,y,x2,y+dy, col=col[i], border=NA)
  }
}

