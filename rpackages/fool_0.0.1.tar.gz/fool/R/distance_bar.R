# Function to plot color bar
distance.bar <- function(x1=0,
                         y1=0,
                         x2=0,
                         y2=0,
                         dist=200000,
                         dbar=0,
                         or="H") {
 if (or=="H") {
  rect(x1,y1,x2,y2,density=15,col="black",angle=45)
  rect(x1,y1,x1+(x2-x1)/2,y2,density=15,col="black",angle=-45)
  text(x1,y1+dbar,"0",cex=1.5)
  text(x2,y1+dbar,"200 Km",cex=1.5)
  text(x1+(x2-x1)/2,y2-dbar,"100 Km",cex=1.5)
 } else if (or=="V") {
  rect(x1,y1,x2,y2,density=15,col="black",angle=45)
  rect(x1,y1,x2,y1+(y2-y1)/2,density=15,col="black",angle=-45)
  text(x2+dbar,y1,"0",cex=1.5)
  text(x2+dbar,y2,"200 Km",cex=1.5)
  text(x2+dbar,y1+(y2-y1)/2,"100 Km",cex=1.5)
 }
# rect(0,7600000,20000,7800000,density=15,col="black",angle=45)
# rect(0,7600000,20000,7700000,density=15,col="black",angle=-45)
# text(40000,7600000,"0",cex=2)
# text(65000,7700000,"100 Km",cex=2)
# text(65000,7800000,"200 Km",cex=2)
}
