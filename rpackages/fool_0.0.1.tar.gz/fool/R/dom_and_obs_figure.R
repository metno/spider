dom_and_obs_figure<-function(fig.par,
                             borders, 
                             orog,
                             obs,
                             offsetx=60000,
                             offsety=70000) {
  if (any(is.na(fig.par$xl))) fig.par$xl<-c(xmin(orog),
                                            xmax(orog))  
  if (any(is.na(fig.par$yl))) fig.par$yl<-c(ymin(orog),
                                            ymax(orog))  
  #
  inside<-extract(orog,cbind(obs$x,obs$y))
  ix<-which(!is.na(inside) & !is.na(obs$value))
  #
  orogv<-getValues(orog)
  ixo<-which(!is.na(orogv))
  xy<-xyFromCell(orog,1:ncell(orog))
  # panel below
  par(mar=c(0.1,.5,48.5,7.))
  plot(xy[ixo,1],-orogv[ixo],
       col="darkgray",pch=19,cex=1.,
       xlim=c(fig.par$xl[1]+offsetx,fig.par$xl[2]-offsetx),axes=F,
#       xlim=c(fig.par$xl[1],fig.par$xl[2]),axes=F,
       main="",xlab="",ylab="")
  points(obs$x[ix],-obs$z[ix],col="navyblue",pch=19,cex=1)
  axis(side=4,at=c(-1000,-2000),labels=c("1000m","2000m"),cex=3,las=1)
  abline(h=seq(-3000,3000,by=500),lty=2)
  abline(h=0,lwd=1)
  box()
  # panel on the right
  par(new=T,mar=c(7,48.5,.5,.5))
  plot(orogv[ixo],xy[ixo,2],
       col="darkgray",pch=19,cex=1.,
       ylim=c(fig.par$yl[1]+offsety,fig.par$yl[2]-offsety),axes=F,
#       ylim=c(fig.par$yl[1],fig.par$yl[2]),axes=F,
       main="",xlab="",ylab="")
  points(obs$z[ix],obs$y[ix],col="navyblue",pch=19,cex=1)
  abline(v=seq(0,3000,by=500),lty=2)
  abline(v=0,lwd=1)
  axis(side=1,at=c(2000),labels=c("2000m"),cex=3,las=3)
  box()
  #
  par(new=T,mar=c(7,.5,.5,7))
  image(orog,
        breaks=fig.par$br,
        col=fig.par$col,
        main="",
        xlab="",
        ylab="",
        xlim=fig.par$xl,
        ylim=fig.par$yl,
        cex.main=1.6,
        axes=F)
  box()
  plot(borders,lwd=2,add=T,usePolypath=F)
  legend(x="bottomright",
         fill=rev(fig.par$col),
         legend=rev(fig.par$tstr),
         cex=2)
  points(obs$x[ix],obs$y[ix],pch=17,col="navyblue",cex=1.5)
  points(obs$x[ix],obs$y[ix],pch=2,col="black",cex=1.5)
}

