#+
field_obs_and_latpan<-function(fig.par,
                               borders, 
                               field,
                               obs,
                               obs_points_on_map=T,
                               obs_points_on_latpan=T,
                               distbar=T,
                               legend=T,
                               legend_as_colorbar=F,
                               offsetx=40000,
                               offsety=50000
                               ) {
#------------------------------------------------------------------------------
  if (any(is.na(fig.par$xl)))
    fig.par$xl<-c(xmin(field),
                  xmax(field))  
  if (any(is.na(fig.par$yl))) 
    fig.par$yl<-c(ymin(field),
                  ymax(field))  
  #
  inside<-extract(field,cbind(obs$x,obs$y))
  ix<-which(!is.na(inside) & !is.na(obs$value))
  if (is.na(fig.par$latpan_step)) fig.par$latpan_step<-10
  if (any(is.na(fig.par$latpan_axl))) 
     fig.par$latpan_axl<-c(floor( min(obs$value[ix],na.rm=T)/
                                  fig.par$latpan_step) * 
                           fig.par$latpan_step,
                           ceiling(max(obs$value[ix],na.rm=T)/
                                   fig.par$latpan_step) * 
                           fig.par$latpan_step)  
  if (any(is.na(fig.par$latpan_bottom_at)))
    fig.par$latpan_bottom_at<-c(10,50)
  if (any(is.na(fig.par$latpan_bottom_lab)))
    fig.par$latpan_bottom_lab<-c("10mm","50mm")
  if (any(is.na(fig.par$latpan_right_at)))
    fig.par$latpan_right_at<-c(50)
  if (any(is.na(fig.par$latpan_right_lab)))
    fig.par$latpan_right_lab<-c("50mm")
  #
  fieldv<-getValues(field)
  ixo<-which(!is.na(fieldv))
  xy<-xyFromCell(field,1:ncell(field))
  #
  #--
  # panel below
  par(mar=c(0.1,.5,48.5,7.))
  plot(xy[ixo,1],
       -fieldv[ixo],
       col="darkgray",
       pch=19,cex=1.,
       xlim=c(fig.par$xl[1]+offsetx,
              fig.par$xl[2]-offsetx),
       ylim=c(-fig.par$latpan_axl[2],
              -fig.par$latpan_axl[1]),
       axes=F,
       main="",xlab="",ylab="")
  if (obs_points_on_latpan) {
    points(obs$x[ix],
           -obs$value[ix],
           col="navyblue",
           pch=19,
           cex=fig.par$platcex)
  }
  axis(side=4,
       at=-fig.par$latpan_bottom_at,
       labels=fig.par$latpan_bottom_lab,
       cex=3,
       las=1)
  abline(h=seq(-fig.par$latpan_axl[2],
               -fig.par$latpan_axl[1],
               by=fig.par$latpan_step),
         lty=2)
  abline(h=0,lwd=1)
  box()
  #
  #--
  # panel on the right
  par(new=T,mar=c(7,48.5,.5,.5))
  plot(fieldv[ixo],
       xy[ixo,2],
       col="darkgray",
       pch=19,
       cex=1.,
       xlim=c(fig.par$latpan_axl[1],
              fig.par$latpan_axl[2]),
       ylim=c(fig.par$yl[1]+offsety,
              fig.par$yl[2]-offsety),
       axes=F,
       main="",xlab="",ylab="")
  if (obs_points_on_latpan) {
    points(obs$value[ix],
           obs$y[ix],
           col="navyblue",
           pch=19,
           cex=fig.par$platcex)
  }
  abline(v=seq(fig.par$latpan_axl[1],
               fig.par$latpan_axl[2],
               by=fig.par$latpan_step),
         lty=2)
  abline(v=0,lwd=1)
  axis(side=4,
       at=-fig.par$latpan_right_at,
       labels=fig.par$latpan_right_lab,
       cex=3,
       las=3)

  box()
  #
  #--
  par(new=T,mar=c(7,.5,.5,7))
  image(field,
        breaks=fig.par$br,
        col=fig.par$col,
        main="",
        xlab="",
        ylab="",
        xlim=fig.par$xl,
        ylim=fig.par$yl,
        cex.main=1.6,
        axes=F)
  box()
  plot(borders,lwd=2,add=T,usePolypath=F)
#  legend(x="bottomright",
#         fill=rev(fig.par$col),
#         legend=rev(fig.par$tstr),
#         cex=fig.par$cexleg)
  if (obs_points_on_map) {
    for (i in 1:length(fig.par$col)) {
      iy<-which(obs$value>fig.par$br[i] & 
                obs$value<=fig.par$br[(i+1)])
      points(obs$x[iy],obs$y[iy],pch=19,
             col=fig.par$col[i],cex=fig.par$pcex)
    }
    points(obs$x,obs$y,pch=1,col="black",cex=fig.par$pcex)
  }
  #
  #--
  if (legend_as_colorbar) {
    dxcb<-abs(fig.par$xl[2]-fig.par$xl[1])/(10*2)
    dycb<-abs(fig.par$yl[2]-fig.par$yl[1])/(10*2)
    x1cb<-fig.par$xl[2]-3*dxcb
    x2cb<-fig.par$xl[2]-2*dxcb
    y1cb<-fig.par$yl[1]+dycb
    y2cb<-fig.par$yl[2]-6*dycb
    color.bar(col=fig.par$col,
              breaks=fig.par$br,
              legtxt=fig.par$legtxt,
              legdig=fig.par$legdig,
              cex=2,
              x1=x1cb,x2=x2cb,y1=y1cb,y2=y2cb,dx=dxcb)
  } else if (legend) {
    legend(x="bottomright",
           fill=rev(fig.par$col),
           legend=rev(fig.par$tstr),
           cex=fig.par$cexleg)
#    if (obs_points_on_map) {
#      for (i in 1:length(fig.par$col)) {
#        iy<-which(obs$value>fig.par$br[i] & 
#                  obs$value<=fig.par$br[(i+1)])
#        points(obs$x[iy],obs$y[iy],pch=19,
#               col=fig.par$col[i],cex=fig.par$pcex)
#      }
#      points(obs$x,obs$y,pch=1,col="black",cex=fig.par$pcex)
#    }
  }
  #
  #--
  if (distbar) {
    dist<-200000
    dxcb<-abs(fig.par$xl[2]-fig.par$xl[1])/(10*2)
    dycb<-abs(fig.par$yl[2]-fig.par$yl[1])/(10*2)
    x1cb<-fig.par$xl[1]+dxcb
    x2cb<-x1cb+dist
    y1cb<-fig.par$yl[2]-0.5*dycb
    y2cb<-fig.par$yl[2]-0.7*dycb
    distance.bar(x1=x1cb,x2=x2cb,y1=y1cb,y2=y2cb,dist=dist,dbar=0.3*dxcb,or="H")
    x1cb<-fig.par$xl[1]+0.1*dxcb
    x2cb<-x1cb+0.2*dxcb
    y2cb<-fig.par$yl[2]-2.*dycb
    y1cb<-y2cb-dist
    distance.bar(x1=x1cb,x2=x2cb,y1=y1cb,y2=y2cb,dist=dist,dbar=1.1*dxcb,or="V")
  }


}

