#+
plot_field_and_obs<-function(fig.par,
                             field=NULL,
                             borders=NULL, 
                             orog=NULL,
                             obs=NULL,
                             offsetx=60000,
                             offsety=70000,
                             obsAsMarker=F,
                             ObsLatPanels=T){
#------------------------------------------------------------------------------
  if (length(fig.par$br)!=(length(fig.par$col)+1)) {
    print("Error: number of breaks must be (number of colors) + 1")
    return(NULL)
  }
  #
  if (any(is.na(fig.par$xl))) {
    if (!is.null(orog)) {
      fig.par$xl<-c(xmin(orog),xmax(orog))  
    } else if (!is.null(field)) {
      fig.par$xl<-c(xmin(field),xmax(field))  
    } else if (!is.null(obs)) { 
      fig.par$xl<-c(min(obs$x),max(obs$x))  
    } else {
      print("Fatal error: cannot find suitable x-limits")
      return(NULL)
    }
  }
  if (any(is.na(fig.par$yl))) {
    if (!is.null(orog)) {
      fig.par$yl<-c(ymin(orog),ymax(orog))  
    } else if (!is.null(field)) {
      fig.par$yl<-c(ymin(field),ymax(field))  
    } else if (!is.null(obs)) { 
      fig.par$yl<-c(min(obs$y),max(obs$y))  
    } else {
      print("Fatal error: cannot find suitable y-limits")
      return(NULL)
    }
  }
  # In case of lateral panels with observation elevation and dem
  if (ObsLatPanels) {
    inside<-extract(orog,cbind(obs$x,obs$y))
    ix<-which(!is.na(inside) & !is.na(obs$value))
    #
    orogv<-getValues(orog)
    ixo<-which(!is.na(orogv))
    xy<-xyFromCell(orog,1:ncell(orog))
    # panel below: orography and station elevation
    par(mar=c(0.1,.5,48.5,7.))
    plot(xy[ixo,1],-orogv[ixo],
         col="darkgray",pch=19,cex=1.,
         xlim=c(fig.par$xl[1]+offsetx,fig.par$xl[2]-offsetx),axes=F,
#         xlim=c(fig.par$xl[1],fig.par$xl[2]),axes=F,
         main="",xlab="",ylab="")
    points(obs$x[ix],-obs$z[ix],col="navyblue",pch=19,cex=1)
    axis(side=4,at=c(-1000,-2000),labels=c("1000m","2000m"),cex=3,las=1)
    abline(h=seq(-3000,3000,by=500),lty=2)
    abline(h=0,lwd=1)
    box()
    # panel on the right: orography and station elevation
    par(new=T,mar=c(7,48.5,.5,.5))
    plot(orogv[ixo],xy[ixo,2],
         col="darkgray",pch=19,cex=1.,
         ylim=c(fig.par$yl[1]+offsety,fig.par$yl[2]-offsety),axes=F,
#         ylim=c(fig.par$yl[1],fig.par$yl[2]),axes=F,
         main="",xlab="",ylab="")
    points(obs$z[ix],obs$y[ix],col="navyblue",pch=19,cex=1)
    abline(v=seq(0,3000,by=500),lty=2)
    abline(v=0,lwd=1)
    axis(side=1,at=c(2000),labels=c("2000m"),cex=3,las=3)
    box()
    # main panel: field on the grid and observed values
    par(new=T,mar=c(7,.5,.5,7))
    image(field,
          breaks=fig.par$br,
          col=fig.par$col,
          main="",
          xlab="",
          ylab="",
          xlim=fig.par$xl,
          ylim=fig.par$yl,
          cex.main=1.6,
          axes=F)
    box()
    if (!is.null(borders)) plot(borders,lwd=2,add=T,usePolypath=F)
    if (!obsAsMarker) {
      for (i in 1:length(fig.par$col)) {
        aux<- obs$value>=fig.par$br[i] & obs$value<fig.par$br[i+1]
        if (any(aux)) {
          ip<-which(aux)
          points(obs$x[ip],obs$y[ip],
                 cex=1,
                 pch=19,
                 col=fig.par$col[i])
          points(obs$x[ip],obs$y[ip],
                 cex=1,
                 col="black")
        }
      }
    } else {
      points(obs$x,obs$y,
             cex=1,
             pch=19,
             col="black")
    }
  # If NO lateral panels are needed (ObsLatPanels=F)
  } else {
    par(mar=c(.5,.5,.5,.5))
    add<-F
    image(field,
          breaks=fig.par$br,
          col=fig.par$col,
          main="",
          xlab="",
          ylab="",
          xlim=fig.par$xl,
          ylim=fig.par$yl,
          cex.main=1.6,
          axes=F,
          add=add)
    box()
    if (!is.null(borders)) plot(borders,lwd=2,add=T,usePolypath=F)
    if (!is.null(obs)) {
      if (!obsAsMarker) {
        for (i in 1:length(fig.par$col)) {
          aux<- obs$value>=fig.par$br[i] & obs$value<fig.par$br[i+1]
          if (any(aux)) {
            ip<-which(aux)
            points(obs$x[ip],obs$y[ip],
                   cex=1,
                   pch=19,
                   col=fig.par$col[i])
            points(obs$x[ip],obs$y[ip],
                   cex=1,
                   col="black")
          }
        }
      } else {
        points(obs$x,obs$y,
               cex=1,
               pch=19,
               col="black")
      }
    }
  }
  # legend
  if (fig.par$legend) {
    legend(x="bottomright",
           fill=rev(fig.par$col),
           legend=rev(fig.par$tstr),
           cex=1)
  }
  # color bar
  if (fig.par$colorbar) {
   dx<-(fig.par$xl[2]-fig.par$xl[1])/30
   dy<-(fig.par$yl[2]-fig.par$yl[1])/30
   color.bar(col=fig.par$col,
             breaks=fig.par$br, 
             nticks=11,
             title='',
             cutTails=T,
             legtxt="degC",
             legdig=0,
             x1=fig.par$xl[2]-2.25*dx,
             y1=fig.par$yl[1]+2*dy,
             x2=fig.par$xl[2]-1.5*dx,
             y2=fig.par$yl[2]-2*dy,
             dx=dx,
             cex=1)
  }
}

