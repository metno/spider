`vedo`<-function(namefileout=NULL,
                 y.data=NULL, # expected $x, $y, $yo, $ydqc.agg
                 y.allblack=F,
                 r.data=NULL,
                 orog=NULL,
                 bound=NULL,
                 par=NULL,
                 legend=T,
                 distbar=T,
                 r.refine=F,
                 extent=NULL,
                 inbox=F,
                 inbox1=F,
                 inbox.mar=NULL
                 ) {
## ydqc==0 good; ydqc==-1 missing; ydqc==1 erroneous
#--------------------------------------------------------------------------------
#
#--------------------------------------------------------------------------------
  if (!is.null(y.data)) {
    y.data$x<-as.numeric(y.data$x)
    y.data$y<-as.numeric(y.data$y)
  }
  leg.str<-vector()
  n.col<-length(par$col.scale)
  #
  png(file=namefileout,width=1200,height=1200)
  par(mar=c(1,1,1,1))
  if (!is.null(orog)) {
    image(orog,
          breaks=c(0,500,1000,1500,2000,2500),
          col=gray(seq(0.7,1,length=5)),
          main=par$main,xlab=par$xlab,ylab=par$ylab,
          xlim=par$xl,ylim=par$yl,cex.main=2.5,axes=F)
  } else {
    orog<-matrix(ncol=2,nrow=2)
    orog[]<-0
    image(orog,
          col="white",
          main=par$main,xlab=par$xlab,ylab=par$ylab,
          xlim=par$xl,ylim=par$yl,cex.main=2.5,axes=F)
  }
  box()
  if (!is.null(r.data)) {
    if (r.refine) {
#      image(r.data,col=par$col.scale,breaks=par$scale,add=T,axes=F)
      rd<-disaggregate(r.data,fact=8,method='bilinear')
      rm<-disaggregate(r.data,fact=8,method='')
      rdm<-mask(rd,rm)
      image(rdm,col=par$col.scale,breaks=par$scale,add=T,axes=F)
    } else {
      image(r.data,col=par$col.scale,breaks=par$scale,add=T,axes=F)
    }
  }
  # observations
  if (!is.null(y.data)) {
    if (y.allblack) {
      points(y.data$x,y.data$y,
             col="black",pch=19,cex=2)
    } else {
      for (c in 1:n.col) {
        in.break<-(!is.na(y.data$yo)) & 
                  (y.data$yo>=par$scale[c]) & 
                  (y.data$yo<par$scale[c+1])
        aux<-which(in.break & 
                   (y.data$ydqc.agg<=0 | is.na(y.data$ydqc.agg)))
        if (length(aux)>0) 
          points(y.data$x[aux],y.data$y[aux],
                 col="black",bg=par$col.scale[c],pch=21,cex=2)
        if (c==1) {
          leg.str[1]<-paste("<",formatC(par$scale[c+1],
                                        format="f",digits=0),sep="")
        } else if (c<n.col) {
          leg.str<-c(leg.str,paste("[",formatC(par$scale[c],
                                        format="f",digits=0),", ",
                               formatC(par$scale[c+1],
                                        format="f",digits=0),")",sep=""))
        } else if (c==n.col) {
          leg.str<-c(leg.str,paste(">",
                             formatC(par$scale[c],format="f",digits=0),sep=""))
        }
        aux<-which(in.break & y.data$ydqc.agg>0)
        if (length(aux)>0) 
          points(y.data$x[aux],y.data$y[aux],
                 bg=par$col.scale[c],col="black",pch=24,cex=2)
      }
    }
  }
  if (!is.null(bound)) plot(bound,add=T,lwd=2)
  if (legend) {
    dxcb<-abs(par$xl[2]-par$xl[1])/(10*2)
    dycb<-abs(par$yl[2]-par$yl[1])/(10*2)
    x1cb<-par$xl[2]-3*dxcb
    x2cb<-par$xl[2]-2*dxcb
    y1cb<-par$yl[1]+dycb
    y2cb<-par$yl[2]-6*dycb
    color.bar(col=par$col.scale,breaks=par$scale,
              legtxt=par$legtxt,legdig=par$legdig,
              x1=x1cb,x2=x2cb,y1=y1cb,y2=y2cb,dx=dxcb)
  }
  if (distbar) {
    dist<-200000
    dxcb<-abs(par$xl[2]-par$xl[1])/(10*2)
    dycb<-abs(par$yl[2]-par$yl[1])/(10*2)
    x1cb<-par$xl[1]+dxcb
    x2cb<-x1cb+dist
    y1cb<-par$yl[2]-0.5*dycb
    y2cb<-par$yl[2]-0.7*dycb
    distance.bar(x1=x1cb,x2=x2cb,y1=y1cb,y2=y2cb,dist=dist,dbar=0.3*dxcb,or="H")
    x1cb<-par$xl[1]+0.1*dxcb
    x2cb<-x1cb+0.2*dxcb
    y2cb<-par$yl[2]-2.*dycb
    y1cb<-y2cb-dist
    distance.bar(x1=x1cb,x2=x2cb,y1=y1cb,y2=y2cb,dist=dist,dbar=0.8*dxcb,or="V")
  }
  if (!is.null(extent)) {
    plot(extent,add=T,lwd=5)
  }
  box()
  if (inbox) {
    print(inbox.mar)
    par(new=T,mar=inbox.mar)
    if (!is.null(extent)) {
      aux<-which(y.data$x>=xmin(extent) & y.data$x<=xmax(extent) &
                 y.data$y>=ymin(extent) & y.data$y<=ymax(extent) &
                 !is.na(y.data$yo) &  y.data$dqcflag==0 &
                 y.data$stid!=12590)
      tmin<-min(c(y.data$yo[aux],rzd,rbzd),na.rm=T)
      tmax<-max(c(y.data$yo[aux],rzd,rbzd),na.rm=T)
      zmin<-0
      zmax<-max(c(y.data$z[aux],od),na.rm=T)
      o<-crop(orog,e)
      od<-getValues(o)
      str<-expression(paste("Temperature [",degree,"C]"))
      plot(y.data$yo[aux],y.data$z[aux],pch=19,cex=0.5,xlim=c(tmin,tmax),
           main="",xlab="",ylab="",cex.axis=2,axes=F)
      rect(tmin,0,tmax,1000,border="white",col="white")
      par(cex.axis=2,lwd=3)
      axis(1)
      axis(2)
      mtext(text=str,side=1,line=3.3,cex=2.5)
      rz<-crop(r,e)
      rzd<-getValues(rz)
      rbz<-crop(rb,e)
      rbzd<-getValues(rbz)
      print(cbind(y.data$z[aux],y.data$stid[aux]))
      mtext(text="Z [m]",side=3,line=-2,cex=2.5,at=(tmin+2))
      points(rbzd,od,col="cyan",pch=19,cex=1)
      points(rzd,od,col="cornflowerblue",pch=19,cex=1)
      points(y.data$yo[aux],y.data$z[aux],col="black",pch=19,cex=2)
    }
  } 
  if (inbox1) {
      par(new=T,mar=inbox.mar)
      o<-crop(orog,extent)
      od<-getValues(o)
      rz<-crop(r,extent)
      rzd<-getValues(rz)
      lf<-list.files(path = "/disk1/data/seNorge2", pattern = "subd",full.names=T)
      nf<-length(lf)
      plot(rz,main="",xlab="",ylab="",axes=F,col="white")
      for (i in 1:nf) {
        load(lf[i])
        r[mask]<-xidi.tmp
        contour(r,levels=0.9,add=T,labels=NULL,drawlabels=F)
      }
  }
  dev.off()
  return()
}

